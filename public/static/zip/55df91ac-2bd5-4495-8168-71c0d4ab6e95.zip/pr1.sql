Name:Saurabh Wagh
Roll No:60
Date:2 Sept
Subject:DBMS Lab


SQL> CREATE USER Saurabh IDENTIFIED BY saurabh;
CREATE USER Saurabh IDENTIFIED BY saurabh
                                 *
ERROR at line 1:
ORA-01031: insufficient privileges 


SQL> CONNECT system/system
Connected.
SQL> CREATE USER Saurabh IDENTIFIED BY saurabh;

User created.

SQL> show user
USER is "SYSTEM"
SQL> GRANT CONNECT,RESOURCE TO Saurabh;

Grant succeeded.

SQL> GRANT CONNECT,RESOURCE TO SYSTEM;

Grant succeeded.

SQL> GRANT UNLIMITED TABLESPACE TO SYSTEM;

Grant succeeded.

SQL> GRANT UNLIMITED DBA TO SYSTEM;
GRANT UNLIMITED DBA TO SYSTEM
      *
ERROR at line 1:
ORA-00990: missing or invalid privilege 


SQL> GRANT DBA TO SYSTEM;

Grant succeeded.

SQL> GRANT CONNECT,RESOURCE TO Saurabh;

Grant succeeded.

SQL> GRANT UNLIMITED DBA TO Saurabh;
GRANT UNLIMITED DBA TO Saurabh
      *
ERROR at line 1:
ORA-00990: missing or invalid privilege 


SQL> CONNECT Saurabh;
Connected.
SQL> GRANT CONNECT,RESOURCE TO Saurabh;
GRANT CONNECT,RESOURCE TO Saurabh
*
ERROR at line 1:
ORA-01031: insufficient privileges 


SQL> GRANT DBA TO Saurabh;
GRANT DBA TO Saurabh
*
ERROR at line 1:
ORA-01031: insufficient privileges 


SQL> CONNECT system/system
Connected.
SQL> GRANT CONNECT,RESOURCE TO Saurabh;

Grant succeeded.

SQL> GRANT UNLIMITED TABLESPACE TO Saurabh;

Grant succeeded.

SQL> GRANT DBA TO Saurabh;

Grant succeeded.

SQL> connect
Enter user-name: Saurabh
Enter password:
Connected.
SQL> create table Course();
create table Course()
                    *
ERROR at line 1:
ORA-00904: : invalid identifier


SQL> create table Course(
  2  cid number(3) not null,
  3  cname varchar(30) not null,
  4  credit number(1),
  5  system
  6  ;

*
ERROR at line 6:
ORA-00907: missing right parenthesis


SQL> create table Course(
  2  cid number(3) not null,
  3  cname varchar2(30) not null,
  4  credit number(1),
  5  constraint course_pk_cid primary key (cid),
  6  constraint course_ck_cid check (cid between 101 and 149),
  7  constraint course_ck_credit check (credit between 1 and 5),
  8  constraint course_uq_cname unique (cname)
  9  );

Table created.

SQL> insert into Course value(102,'Data Structure's',4);
ERROR:
ORA-01756: quoted string not properly terminated


SQL> insert into Course value(102,'Data Structures',4);
insert into Course value(102,'Data Structures',4)
                         *
ERROR at line 1:
ORA-00928: missing SELECT keyword


SQL> select * from Course
  2  ;

no rows selected

SQL> insert into Course values(102,'DSA',4);

1 row created.

SQL> select * from Course;

       CID CNAME                              CREDIT
---------- ------------------------------ ----------
       102 DSA                                     4

SQL> create table Participant(
  2  pid number(4) not null,
  3  pname varchar(50) not null,
  4  gender char(1) not null,
  5  cid number(3),
  6  constraint participant_pk_pid primary key (pid),
  7  constraint participant_ck_pid check (pid between 1001 and 9999),
  8  constraint participant_ck_gender check (gender in ('M','F')),
  9  constraint participant_fk_course_cid foreign key
 10  (cid) references Course(cid)
 11
SQL> create table Participant(
  2  pid number(4) not null,
  3  pname varchar(50) not null,
  4  gender char(1) not null,
  5  cid number(3),
  6  constraint participant_pk_pid primary key (pid),
  7  constraint participant_ck_pid check (pid between 1001 and 9999),
  8  constraint participant_ck_gender check (gender in ('M','F')),
  9  constraint participant_fk_course_cid foreign key
 10  (cid) references Course(cid)
 11  );

Table created.

SQL> insert into Course values(102,'DSA',4);
insert into Course values(102,'DSA',4)
*
ERROR at line 1:
ORA-00001: unique constraint (SAURABH.COURSE_PK_CID) violated


SQL> insert into Course values(103,'DBMS',4);

1 row created.

SQL> insert into Course values(101,'CN',3);

1 row created.

SQL> insert into Course values(104,'CN',6);
insert into Course values(104,'CN',6)
*
ERROR at line 1:
ORA-02290: check constraint (SAURABH.COURSE_CK_CREDIT) violated


SQL> insert into Course values(104,'DAA',6);
insert into Course values(104,'DAA',6)
*
ERROR at line 1:
ORA-02290: check constraint (SAURABH.COURSE_CK_CREDIT) violated


SQL> insert into Course values(104,'DAA',5);

1 row created.

SQL> select * from Course;

       CID CNAME                              CREDIT
---------- ------------------------------ ----------
       102 DSA                                     4
       103 DBMS                                    4
       101 CN                                      3
       104 DAA                                     5

SQL> insert into Course values(105,'BC',2);

1 row created.

SQL> select * from Course;

       CID CNAME                              CREDIT
---------- ------------------------------ ----------
       102 DSA                                     4
       103 DBMS                                    4
       101 CN                                      3
       104 DAA                                     5
       105 BC                                      2

SQL> commit;

Commit complete.

SQL> insert into Participant values(1002,'Saurabh','M',104);

1 row created.

SQL> insert into Participant values(1003,'Smit','M',102);

1 row created.

SQL> insert into Participant values(1002,'Shreyansh','M',104);
insert into Participant values(1002,'Shreyansh','M',104)
*
ERROR at line 1:
ORA-00001: unique constraint (SAURABH.PARTICIPANT_PK_PID) violated


SQL> insert into Participant values(1003,'Shreyansh','M',104);
insert into Participant values(1003,'Shreyansh','M',104)
*
ERROR at line 1:
ORA-00001: unique constraint (SAURABH.PARTICIPANT_PK_PID) violated


SQL> insert into Participant values(1004,'Shreyansh','M',104);

1 row created.

SQL> insert into Participant values(1005,'Shreyansh','G',104);
insert into Participant values(1005,'Shreyansh','G',104)
*
ERROR at line 1:
ORA-02290: check constraint (SAURABH.PARTICIPANT_CK_GENDER) violated


SQL> insert into Participant values(1005,'Rashmi','F',101);

1 row created.

SQL> select * from Participant;

       PID PNAME                                              G        CID
---------- -------------------------------------------------- - ----------
      1002 Saurabh                                            M        104
      1003 Smit                                               M        102
      1004 Shreyansh                                          M        104
      1005 Rashmi                                             F        101

SQL> insert into Participant values(1000,'jaya','F',105);
insert into Participant values(1000,'jaya','F',105)
*
ERROR at line 1:
ORA-02290: check constraint (SAURABH.PARTICIPANT_CK_PID) violated


SQL> insert into Participant values(1006,'jaya','F',105);

1 row created.

SQL> select * from Participant;

       PID PNAME                                              G        CID
---------- -------------------------------------------------- - ----------
      1002 Saurabh                                            M        104
      1003 Smit                                               M        102
      1004 Shreyansh                                          M        104
      1005 Rashmi                                             F        101
      1006 jaya                                               F        105

SQL> insert into Participant values(1007,'Shruti','F',100);
insert into Participant values(1007,'Shruti','F',100)
*
ERROR at line 1:
ORA-02291: integrity constraint (SAURABH.PARTICIPANT_FK_COURSE_CID) violated -
parent key not found


SQL> select * from Participant;

       PID PNAME                                              G        CID
---------- -------------------------------------------------- - ----------
      1002 Saurabh                                            M        104
      1003 Smit                                               M        102
      1004 Shreyansh                                          M        104
      1005 Rashmi                                             F        101
      1006 jaya                                               F        105

SQL> commit;

Commit complete.

SQL> insert into Participant values(1007,'Shruti','F',null);

1 row created.

SQL> select * from Participant inner join Course on Participant.cid = Course.cid;

       PID PNAME                                              G        CID
---------- -------------------------------------------------- - ----------
       CID CNAME                              CREDIT
---------- ------------------------------ ----------
      1003 Smit                                               M        102
       102 DSA                                     4

      1005 Rashmi                                             F        101
       101 CN                                      3

      1004 Shreyansh                                          M        104
       104 DAA                                     5


       PID PNAME                                              G        CID
---------- -------------------------------------------------- - ----------
       CID CNAME                              CREDIT
---------- ------------------------------ ----------
      1002 Saurabh                                            M        104
       104 DAA                                     5

      1006 jaya                                               F        105
       105 BC                                      2


SQL> select pname,credit from Participant inner join Course on Participant.cid = Course.cid;

PNAME                                                  CREDIT
-------------------------------------------------- ----------
Smit                                                        4
Rashmi                                                      3
Shreyansh                                                   5
Saurabh                                                     5
jaya                                                        2

SQL> select pname,credit,cname from Participant inner join Course on Participant.cid = Course.cid;

PNAME                                                  CREDIT
-------------------------------------------------- ----------
CNAME
------------------------------
Smit                                                        4
DSA

Rashmi                                                      3
CN

Shreyansh                                                   5
DAA


PNAME                                                  CREDIT
-------------------------------------------------- ----------
CNAME
------------------------------
Saurabh                                                     5
DAA

jaya                                                        2
BC


SQL> desc user_constraints
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 OWNER                                              VARCHAR2(30)
 CONSTRAINT_NAME                           NOT NULL VARCHAR2(30)
 CONSTRAINT_TYPE                                    VARCHAR2(1)
 TABLE_NAME                                NOT NULL VARCHAR2(30)
 SEARCH_CONDITION                                   LONG
 R_OWNER                                            VARCHAR2(30)
 R_CONSTRAINT_NAME                                  VARCHAR2(30)
 DELETE_RULE                                        VARCHAR2(9)
 STATUS                                             VARCHAR2(8)
 DEFERRABLE                                         VARCHAR2(14)
 DEFERRED                                           VARCHAR2(9)
 VALIDATED                                          VARCHAR2(13)
 GENERATED                                          VARCHAR2(14)
 BAD                                                VARCHAR2(3)
 RELY                                               VARCHAR2(4)
 LAST_CHANGE                                        DATE
 INDEX_OWNER                                        VARCHAR2(30)
 INDEX_NAME                                         VARCHAR2(30)
 INVALID                                            VARCHAR2(7)
 VIEW_RELATED                                       VARCHAR2(14)

SQL> commit;

Commit complete.

SQL> select constraint_name, constraint_type, table_name from user_constraints;

CONSTRAINT_NAME                C TABLE_NAME
------------------------------ - ------------------------------
SYS_C0011116                   C COURSE
SYS_C0011117                   C COURSE
COURSE_CK_CID                  C COURSE
COURSE_CK_CREDIT               C COURSE
SYS_C0011122                   C PARTICIPANT
SYS_C0011123                   C PARTICIPANT
SYS_C0011124                   C PARTICIPANT
PARTICIPANT_CK_PID             C PARTICIPANT
PARTICIPANT_CK_GENDER          C PARTICIPANT
PARTICIPANT_FK_COURSE_CID      R PARTICIPANT
COURSE_PK_CID                  P COURSE

CONSTRAINT_NAME                C TABLE_NAME
------------------------------ - ------------------------------
COURSE_UQ_CNAME                U COURSE
PARTICIPANT_PK_PID             P PARTICIPANT

13 rows selected.

SQL> select constraint_name, constraint_type, table_name from user_constraints where table_name='Course';

no rows selected

SQL> select constraint_name, constraint_type, table_name from user_constraints where table_name='COURSE';

CONSTRAINT_NAME                C TABLE_NAME
------------------------------ - ------------------------------
SYS_C0011116                   C COURSE
SYS_C0011117                   C COURSE
COURSE_CK_CID                  C COURSE
COURSE_CK_CREDIT               C COURSE
COURSE_PK_CID                  P COURSE
COURSE_UQ_CNAME                U COURSE

6 rows selected.

SQL> select constraint_name, constraint_type, table_name from user_constraints where table_name='PARTICIPANT';

CONSTRAINT_NAME                C TABLE_NAME
------------------------------ - ------------------------------
SYS_C0011122                   C PARTICIPANT
SYS_C0011123                   C PARTICIPANT
SYS_C0011124                   C PARTICIPANT
PARTICIPANT_CK_PID             C PARTICIPANT
PARTICIPANT_CK_GENDER          C PARTICIPANT
PARTICIPANT_PK_PID             P PARTICIPANT
PARTICIPANT_FK_COURSE_CID      R PARTICIPANT

7 rows selected.

SQL> commit;

Commit complete.

SQL> spool off;