SQL> connect
Enter user-name: Saurabh
Connected.
SQL> select * from Student;

no rows selected

SQL> desc Student;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 NAME                                               VARCHAR2(100)
 ROLLNO                                    NOT NULL NUMBER(38)
 AGE                                                NUMBER(38)

SQL> select * from Student;

no rows selected

SQL> desc user_constraints;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 OWNER                                              VARCHAR2(30)
 CONSTRAINT_NAME                           NOT NULL VARCHAR2(30)
 CONSTRAINT_TYPE                                    VARCHAR2(1)
 TABLE_NAME                                NOT NULL VARCHAR2(30)
 SEARCH_CONDITION                                   LONG
 R_OWNER                                            VARCHAR2(30)
 R_CONSTRAINT_NAME                                  VARCHAR2(30)
 DELETE_RULE                                        VARCHAR2(9)
 STATUS                                             VARCHAR2(8)
 DEFERRABLE                                         VARCHAR2(14)
 DEFERRED                                           VARCHAR2(9)
 VALIDATED                                          VARCHAR2(13)
 GENERATED                                          VARCHAR2(14)
 BAD                                                VARCHAR2(3)
 RELY                                               VARCHAR2(4)
 LAST_CHANGE                                        DATE
 INDEX_OWNER                                        VARCHAR2(30)
 INDEX_NAME                                         VARCHAR2(30)
 INVALID                                            VARCHAR2(7)
 VIEW_RELATED                                       VARCHAR2(14)

SQL> desc Participants
ERROR:
ORA-04043: object Participants does not exist 


SQL> desc Participant;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 PID                                       NOT NULL NUMBER(4)
 PNAME                                     NOT NULL VARCHAR2(50)
 GENDER                                    NOT NULL CHAR(1)
 CID                                                NUMBER(3)

SQL> desc Course;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 CID                                       NOT NULL NUMBER(3)
 CNAME                                     NOT NULL VARCHAR2(30)
 CREDIT                                             NUMBER(1)

SQL> select * from Participant;

       PID PNAME                                              G        CID      
---------- -------------------------------------------------- - ----------      
      1002 Saurabh                                            M        104      
      1003 Smit                                               M        102      
      1004 Shreyansh                                          M        104      
      1005 Rashmi                                             F        101      
      1006 jaya                                               F        105      
      1007 Shruti                                             F                 

6 rows selected.

SQL> delete from Participant where cid=104;

2 rows deleted.

SQL> rollback;

Rollback complete.

SQL> select * from Course;

       CID CNAME                              CREDIT                            
---------- ------------------------------ ----------                            
       102 DSA                                     4                            
       103 DBMS                                    4                            
       101 CN                                      3                            
       104 DAA                                     5                            
       105 BC                                      2                            

SQL> delete from Course where cid=104;
delete from Course where cid=104
*
ERROR at line 1:
ORA-02292: integrity constraint (SAURABH.PARTICIPANT_FK_COURSE_CID) violated - 
child record found 


SQL> alter table Course drop constraint PARTICIPANT_FK_COURSE_CID;
alter table Course drop constraint PARTICIPANT_FK_COURSE_CID
                                   *
ERROR at line 1:
ORA-02443: Cannot drop constraint  - nonexistent constraint 


SQL> alter table Course drop constraint PARTICIPANT_FK_COURSE;
alter table Course drop constraint PARTICIPANT_FK_COURSE
                                   *
ERROR at line 1:
ORA-02443: Cannot drop constraint  - nonexistent constraint 


SQL> alter table Participant drop constraint PARTICIPANT_FK_COURSE_CID;

Table altered.

SQL> alter table Participant add constraint PARTICIPANT_FK_COURSE_CID;
alter table Participant add constraint PARTICIPANT_FK_COURSE_CID
                                                               *
ERROR at line 1:
ORA-00904: : invalid identifier 


SQL> alter table Participant add constraint PARTICIPANT_FK_COURSE_CID foreign key (cid) references Course(cid) on delete cascade;

Table altered.

SQL> commit;

Commit complete.

SQL> select * from Course;

       CID CNAME                              CREDIT                            
---------- ------------------------------ ----------                            
       102 DSA                                     4                            
       103 DBMS                                    4                            
       101 CN                                      3                            
       104 DAA                                     5                            
       105 BC                                      2                            

SQL> select * from Participant;

       PID PNAME                                              G        CID      
---------- -------------------------------------------------- - ----------      
      1002 Saurabh                                            M        104      
      1003 Smit                                               M        102      
      1004 Shreyansh                                          M        104      
      1005 Rashmi                                             F        101      
      1006 jaya                                               F        105      
      1007 Shruti                                             F                 

6 rows selected.

SQL> delete from Course where cid=104;

1 row deleted.

SQL> select * from Participant;

       PID PNAME                                              G        CID      
---------- -------------------------------------------------- - ----------      
      1003 Smit                                               M        102      
      1005 Rashmi                                             F        101      
      1006 jaya                                               F        105      
      1007 Shruti                                             F                 

SQL> select * from Course;

       CID CNAME                              CREDIT                            
---------- ------------------------------ ----------                            
       102 DSA                                     4                            
       103 DBMS                                    4                            
       101 CN                                      3                            
       105 BC                                      2                            

SQL> rollback;

Rollback complete.

SQL> alter table Participant drop constraint PARTICIPANT_FK_COURSE_CID;

Table altered.

SQL> alter table Participant add constraint PARTICIPANT_FK_COURSE_CID foreign key (cid) references Course(cid) on delete no action;
alter table Participant add constraint PARTICIPANT_FK_COURSE_CID foreign key (cid) references Course(cid) on delete no action
                                                                                                                    *
ERROR at line 1:
ORA-00905: missing keyword 


SQL> alter table Participant add constraint PARTICIPANT_FK_COURSE_CID foreign key (cid) references Course(cid) on delete noaction;
alter table Participant add constraint PARTICIPANT_FK_COURSE_CID foreign key (cid) references Course(cid) on delete noaction
                                                                                                                    *
ERROR at line 1:
ORA-00905: missing keyword 


SQL> alter table Participant add constraint PARTICIPANT_FK_COURSE_CID foreign key (cid) references Course(cid) on delete set null;

Table altered.

SQL> delete from Course where cid=104;

1 row deleted.

SQL> select * from Course;

       CID CNAME                              CREDIT                            
---------- ------------------------------ ----------                            
       102 DSA                                     4                            
       103 DBMS                                    4                            
       101 CN                                      3                            
       105 BC                                      2                            

SQL> select * from Participant;

       PID PNAME                                              G        CID      
---------- -------------------------------------------------- - ----------      
      1002 Saurabh                                            M                 
      1003 Smit                                               M        102      
      1004 Shreyansh                                          M                 
      1005 Rashmi                                             F        101      
      1006 jaya                                               F        105      
      1007 Shruti                                             F                 

6 rows selected.

SQL> commit;

Commit complete.

SQL> spool off;
